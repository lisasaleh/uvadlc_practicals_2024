################################################################################
# MIT License
#
# Copyright (c) 2024 University of Amsterdam
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to conditions.
#
# Author: Deep Learning Course (UvA) | Fall 2024
# Date Created: 2024-10-28
################################################################################
"""
This module implements various modules of the network.
You should fill in code into indicated sections.
"""
import numpy as np


class LinearModule(object):
    """
    Linear module. Applies a linear transformation to the input data.
    """

    def __init__(self, in_features, out_features, input_layer=False):
        """
        Initializes the parameters of the module.

        Args:
          in_features: size of each input sample
          out_features: size of each output sample
          input_layer: boolean, True if this is the first layer after the input, else False.

        TODO:
        Initialize weight parameters using Kaiming initialization.
        Initialize biases with zeros.
        Hint: the input_layer argument might be needed for the initialization

        Also, initialize gradients with zeros.
        """
        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Kaiming initialization
        std = np.sqrt(2 / in_features)
        self.params = {
            'weight': np.random.normal(0, std, (out_features, in_features)),
            'bias': np.zeros((1, out_features)),
        }
        # Gradients
        self.grads = {
            'weight': np.zeros((out_features, in_features)),
            'bias': np.zeros((1, out_features)),
        }
        #######################
        # END OF YOUR CODE    #
        #######################


    def forward(self, x):
        """
        Forward pass.

        Args:
          x: input to the module
        Returns:
          out: output of the module

        TODO:
        Implement forward pass of the module.

        Hint: You can store intermediate variables inside the object. They can be used in backward pass computation.
        """
        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Save input for use in the backward pass
        self.input = x

        # Compute linear transformation
        out = np.dot(x, self.params['weight'].T) + self.params['bias']

        #######################
        # END OF YOUR CODE    #
        #######################

        return out

    def backward(self, dout):
        """
        Backward pass.

        Args:
          dout: gradients of the previous module
        Returns:
          dx: gradients with respect to the input of the module

        TODO:
        Implement backward pass of the module. Store gradient of the loss with respect to
        layer parameters in self.grads['weight'] and self.grads['bias'].
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Compute gradients for weights and biases
        self.grads['weight'] = np.dot(dout.T, self.input)  # Weight gradient
        self.grads['bias'] = np.sum(dout, axis=0, keepdims=True)  # Bias gradient

        # Compute gradient with respect to the input
        dx = np.dot(dout, self.params['weight'])  # Input gradient

        #######################
        # END OF YOUR CODE    #
        #######################
        return dx

    def clear_cache(self):
        """
        Remove any saved tensors for the backward pass.
        Used to clean-up model from any remaining input data when we want to save it.

        TODO:
        Set any caches you have to None.
        """
        #######################
        # PUT YOUR CODE HERE  #
        #######################
        self.input = None
        #######################
        # END OF YOUR CODE    #
        #######################


class ELUModule(object):
    """
    ELU activation module.
    """

    def __init__(self, alpha):
        self.alpha = alpha

    def forward(self, x):
        """
        Forward pass.

        Args:
          x: input to the module
        Returns:
          out: output of the module

        TODO:
        Implement forward pass of the module.

        Hint: You can store intermediate variables inside the object. They can be used in backward pass computation.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        self.input = x  # Cache the input for the backward pass

        # Element-wise ELU calculation
        out = np.where(x > 0, x, self.alpha * (np.exp(x) - 1))

        #######################
        # END OF YOUR CODE    #
        #######################

        return out

    def backward(self, dout):
        """
        Backward pass.
        Args:
          dout: gradients of the previous module
        Returns:
          dx: gradients with respect to the input of the module

        TODO:
        Implement backward pass of the module.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Compute the local gradient of ELU
        local_grad = np.where(self.input > 0, 1, self.alpha * np.exp(self.input))

        # Compute the gradient of the loss with respect to the input
        dx = dout * local_grad


        #######################
        # END OF YOUR CODE    #
        #######################
        return dx

    def clear_cache(self):
        """
        Remove any saved tensors for the backward pass.
        Used to clean-up model from any remaining input data when we want to save it.

        TODO:
        Set any caches you have to None.
        """
        #######################
        # PUT YOUR CODE HERE  #
        #######################
        self.input = None


        #######################
        # END OF YOUR CODE    #
        #######################


class SoftMaxModule(object):
    """
    Softmax activation module.
    """

    def forward(self, x):
        """
        Forward pass.
        Args:
          x: input to the module
        Returns:
          out: output of the module

        TODO:
        Implement forward pass of the module.
        To stabilize computation you should use the so-called Max Trick - https://timvieira.github.io/blog/post/2014/02/11/exp-normalize-trick/

        Hint: You can store intermediate variables inside the object. They can be used in backward pass computation.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Stabilize input by subtracting max along rows
        x_stable = x - np.max(x, axis=1, keepdims=True)

        # Compute softmax
        exp_x = np.exp(x_stable)
        out = exp_x / np.sum(exp_x, axis=1, keepdims=True)

        # Cache the output for backward pass
        self.output = out

        #######################
        # END OF YOUR CODE    #
        #######################


        return out

    def backward(self, dout):
        """
        Backward pass.
        Args:
          dout: gradients of the previous modul
        Returns:
          dx: gradients with respect to the input of the module

        TODO:
        Implement backward pass of the module.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        dx = self.output * (dout - np.sum(dout * self.output, axis=1, keepdims=True))

        #######################
        # END OF YOUR CODE    #
        #######################

        return dx

    def clear_cache(self):
        """
        Remove any saved tensors for the backward pass.
        Used to clean-up model from any remaining input data when we want to save it.

        TODO:
        Set any caches you have to None.
        """
        #######################
        # PUT YOUR CODE HERE  #
        #######################
        self.output = None

        #######################
        # END OF YOUR CODE    #
        #######################


class CrossEntropyModule(object):
    """
    Cross entropy loss module.
    """

    def forward(self, x, y):
        """
        Forward pass.
        Args:
          x: input to the module
          y: labels of the input
        Returns:
          out: cross entropy loss

        TODO:
        Implement forward pass of the module.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Clip x to prevent log(0)
        x_clipped = np.clip(x, 1e-12, 1.0)

        # Convert class indices to one-hot encoding
        y_one_hot = np.zeros_like(x)
        y_one_hot[np.arange(x.shape[0]), y] = 1

        # Compute cross-entropy loss
        out = -np.sum(y_one_hot * np.log(x_clipped)) / x.shape[0]
        #######################
        # END OF YOUR CODE    #
        #######################

        return out

    def backward(self, x, y):
        """
        Backward pass.
        Args:
          x: input to the module
          y: labels of the input
        Returns:
          dx: gradient of the loss with the respect to the input x.

        TODO:
        Implement backward pass of the module.
        """

        #######################
        # PUT YOUR CODE HERE  #
        #######################
        # Clip x to prevent division by zero
        x_clipped = np.clip(x, 1e-12, 1.0)

        # Convert class indices to one-hot encoding
        y_one_hot = np.zeros_like(x)
        y_one_hot[np.arange(x.shape[0]), y] = 1

        # Compute gradient
        dx = -y_one_hot / x_clipped
        dx /= x.shape[0]  # Normalize by batch size
        #######################
        # END OF YOUR CODE    #
        #######################

        return dx